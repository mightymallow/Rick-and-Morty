import Episode1 from './thumbnails/e1.jpg'
import Episode2 from './thumbnails/e2.jpg'
import Episode3 from './thumbnails/e3.jpg'
import Episode4 from './thumbnails/e4.jpg'
import Episode5 from './thumbnails/e5.jpg'
import Episode6 from './thumbnails/e6.jpg'
import Episode7 from './thumbnails/e7.jpg'
import Episode8 from './thumbnails/e8.jpg'
import Episode9 from './thumbnails/e9.jpg'
import Episode10 from './thumbnails/e10.jpg'
import Episode11 from './thumbnails/e11.jpg'

export const Title = require('./misc/title.png')
export const Thumbnails = [
  Episode1,
  Episode2,
  Episode3,
  Episode4,
  Episode5,
  Episode6,
  Episode7,
  Episode8,
  Episode9,
  Episode10,
  Episode11
]
